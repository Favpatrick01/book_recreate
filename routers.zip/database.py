from schemas.book import Book


books: dict[str, Book] = {}
